package com.cg.paymentwalletappjpa.service;

import com.cg.paymentwalletappjpa.dao.IPaymentDao;
import com.cg.paymentwalletappjpa.dao.PaymentDaoImpl;
import com.cg.paymentwalletappjpa.dto.Customer;
import com.cg.paymentwalletappjpa.exception.IPaymentException;
import com.cg.paymentwalletappjpa.exception.PaymentException;

public class PaymentService implements IPaymentService{
	IPaymentDao dao = new PaymentDaoImpl();

	public void createAccount(Customer wallet) {
		dao.beginTransaction();
		dao.createAccount(wallet);
		dao.commitTransaction();
	}

	public double showBalance(String userId) {

		double balance = 0;
		dao.beginTransaction();
		balance = dao.showBalance(userId);
		dao.commitTransaction();
		return balance;
	}

	public boolean deposit(String userId, double amount) {
		boolean result = false;
		if (amount > 0) {
			dao.beginTransaction();
			dao.deposit(userId, amount);
			dao.commitTransaction();
			result = true;
		}
		return result;
	}

	public boolean withdraw(String userId, double amount) {
		boolean result = false;
		if (dao.showBalance(userId) >= amount) {
			dao.beginTransaction();
			dao.withdraw(userId, amount);
			dao.commitTransaction();
			result = true;
		}
		return result;
	}

	public boolean fundTransfer(String userIdSender, String userIdReceiver, double amount) throws PaymentException {
		boolean result = false;
		if (dao.showBalance(userIdSender) >= amount) {
			dao.beginTransaction();
			dao.fundTransfer(userIdSender, userIdReceiver, amount);
			dao.commitTransaction();
			result = true;
		}
		return result;
	}

	public boolean validateDetails(Customer customer) throws PaymentException {
		boolean result = true;
		String regex = "[A-Z]{1}[a-z]+";
		String regex2 = "[0-9]{10}";
		String regex3 = "[a-z0-9_.]{1,}@[a-z]{1,10}.com";
		String regex4 = "[A-Za-z0-9]{4,}";
		if (customer.getName().matches(regex)) {

			if (customer.getPhNumber().matches(regex2)) {

				if (customer.getEmailId().matches(regex3)) {

					if (!(customer.getUserId().equals(customer.getWallet().getPassword()))) {

						if (customer.getUserId().matches(regex4)) {

							if (customer.getWallet().getPassword().length() >= 8) {

								result = true;

							} else
								throw new PaymentException(IPaymentException.ERROR9);

						} else
							throw new PaymentException(IPaymentException.ERROR8);

					} else
						throw new PaymentException(IPaymentException.ERROR7);

				} else
					throw new PaymentException(IPaymentException.ERROR3);

			} else
				throw new PaymentException(IPaymentException.ERROR2);

		} else
			throw new PaymentException(IPaymentException.ERROR1);
		return result;

	}

	public Customer login(String id, String password) throws PaymentException {

		Customer wallet = new Customer();
		if (dao.login(id, password) != null) {

			wallet = dao.login(id, password);
		} else
			throw new PaymentException(IPaymentException.ERROR5);

		return wallet;
	}

	public String printTransaction(String userId) {

		dao.beginTransaction();
		String trans = dao.printTransactions(userId);
		dao.commitTransaction();
		return trans;
	}

}
