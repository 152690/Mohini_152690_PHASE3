package com.cg.paymentwalletappjpa.dao;

import com.cg.paymentwalletappjpa.dto.Customer;
import com.cg.paymentwalletappjpa.exception.PaymentException;

public interface IPaymentDao {

	public void createAccount(Customer customer);

	public double showBalance(String userId);

	public void deposit(String userId, double amount);

	public void withdraw(String userId, double amount);

	public void fundTransfer(String userIdSender, String userIdReceiver, double amount) throws PaymentException;

	public String printTransactions(String userId);

	public Customer login(String id, String password) throws PaymentException;

	void beginTransaction();

	void commitTransaction();
}
